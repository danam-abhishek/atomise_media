import { useState } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import OurServicesSection from "@/components/OurServicesSection";
import PricingSection from "@/components/PricingSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import ContactModal from "@/components/ContactModal";
import CursorTrail from "@/components/CursorTrail";

const Index = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalServiceTitle, setModalServiceTitle] = useState<string | undefined>();

  const handleOpenModal = (serviceTitle?: string) => {
    setModalServiceTitle(serviceTitle);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setModalServiceTitle(undefined);
  };

  return (
    <div className="min-h-screen bg-background">
      <CursorTrail />
      <Navbar onOpenModal={() => handleOpenModal()} />
      <HeroSection onOpenModal={() => handleOpenModal()} />
      <OurServicesSection onOpenModal={() => handleOpenModal()} />
      <PricingSection onOpenModal={() => handleOpenModal()} />
      <ContactSection />
      <Footer />
      <ContactModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        serviceTitle={modalServiceTitle}
      />
    </div>
  );
};

export default Index;
