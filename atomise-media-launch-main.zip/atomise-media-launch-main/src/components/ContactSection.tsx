import { useState } from "react";
import { Check, Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useScrollReveal } from "@/hooks/useScrollReveal";

const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    countryCode: "+91",
    businessType: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { ref, isVisible } = useScrollReveal();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    
    // Reset after 5 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: "",
        email: "",
        phone: "",
        countryCode: "+91",
        businessType: "",
        message: "",
      });
    }, 5000);
  };

  return (
    <section id="contact" className="py-24 gradient-hero relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-20 w-64 h-64 bg-background/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-20 w-96 h-96 bg-background/10 rounded-full blur-3xl" />
      </div>

      <div className="container relative z-10 mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-deep-navy mb-4">
            Ready to Atomise Your Brand?
          </h2>
          <p className="text-lg text-deep-navy/80">
            Let's talk. Our team is standing by to help you grow.
          </p>
        </div>

        {/* Contact Form */}
        <div
          ref={ref}
          className={`max-w-2xl mx-auto ${isVisible ? "animate-fade-in-up" : "opacity-0"}`}
        >
          <div className="bg-card rounded-2xl p-8 md:p-12 shadow-lg border border-border">
            {isSubmitted ? (
              <div className="text-center py-8 animate-fade-in-up">
                <div className="w-20 h-20 rounded-full gradient-button mx-auto flex items-center justify-center mb-6">
                  <Check className="w-10 h-10 text-primary-foreground" />
                </div>
                <h3 className="text-2xl font-bold text-foreground mb-3">
                  Thank You!
                </h3>
                <p className="text-muted-foreground">
                  We've received your application. Our team will reach out within 4 hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="contact-name" className="text-foreground font-medium">
                      Name
                    </Label>
                    <Input
                      id="contact-name"
                      type="text"
                      placeholder="Your full name"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      required
                      className="mt-2 border-border focus:border-primary focus:ring-primary"
                    />
                  </div>

                  <div>
                    <Label htmlFor="contact-email" className="text-foreground font-medium">
                      Email
                    </Label>
                    <Input
                      id="contact-email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      required
                      className="mt-2 border-border focus:border-primary focus:ring-primary"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="contact-phone" className="text-foreground font-medium">
                      Phone Number
                    </Label>
                    <div className="flex gap-2 mt-2">
                      <Select
                        value={formData.countryCode}
                        onValueChange={(value) =>
                          setFormData({ ...formData, countryCode: value })
                        }
                      >
                        <SelectTrigger className="w-28 border-border">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="+91">+91 🇮🇳</SelectItem>
                          <SelectItem value="+1">+1 🇺🇸</SelectItem>
                          <SelectItem value="+971">+971 🇦🇪</SelectItem>
                          <SelectItem value="+44">+44 🇬🇧</SelectItem>
                          <SelectItem value="+61">+61 🇦🇺</SelectItem>
                        </SelectContent>
                      </Select>
                      <Input
                        id="contact-phone"
                        type="tel"
                        placeholder="Phone number"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        required
                        className="flex-1 border-border focus:border-primary focus:ring-primary"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="contact-business" className="text-foreground font-medium">
                      Business Type
                    </Label>
                    <Select
                      value={formData.businessType}
                      onValueChange={(value) =>
                        setFormData({ ...formData, businessType: value })
                      }
                      required
                    >
                      <SelectTrigger className="mt-2 border-border">
                        <SelectValue placeholder="Select your business type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="small">Small Business</SelectItem>
                        <SelectItem value="medium">Medium Business</SelectItem>
                        <SelectItem value="large">Large Enterprise</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="contact-message" className="text-foreground font-medium">
                    Message (Optional)
                  </Label>
                  <Textarea
                    id="contact-message"
                    placeholder="Tell us about your business and goals..."
                    value={formData.message}
                    onChange={(e) =>
                      setFormData({ ...formData, message: e.target.value })
                    }
                    className="mt-2 min-h-[120px] border-border focus:border-primary focus:ring-primary"
                  />
                </div>

                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full gradient-button text-primary-foreground border-0 py-6 text-lg font-semibold hover-glow transition-all"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Submit Application
                    </>
                  )}
                </Button>

                <p className="text-center text-sm text-muted-foreground">
                  Our team will respond within 4 hours. We're fast, professional, and ready to help you succeed.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
