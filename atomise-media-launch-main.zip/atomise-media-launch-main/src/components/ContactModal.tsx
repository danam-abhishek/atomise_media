import { useState } from "react";
import { X, Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  serviceTitle?: string;
}

const ContactModal = ({ isOpen, onClose, serviceTitle }: ContactModalProps) => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    countryCode: "+91",
    businessType: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    
    // Reset after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        name: "",
        email: "",
        phone: "",
        countryCode: "+91",
        businessType: "",
      });
      onClose();
    }, 3000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-deep-navy/60 backdrop-blur-sm animate-fade-in"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative w-full max-w-md bg-card rounded-2xl shadow-lg animate-scale-in overflow-hidden">
        {/* Header */}
        <div className="gradient-hero p-6 text-center">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-primary-foreground/20 hover:bg-primary-foreground/30 transition-colors"
          >
            <X className="w-5 h-5 text-primary-foreground" />
          </button>
          <h2 className="text-2xl font-bold text-deep-navy">
            {serviceTitle || "Let's Start Your Growth Journey"}
          </h2>
          <p className="text-deep-navy/80 mt-2 text-sm">
            Fill in your details and we'll get back to you within 4 hours
          </p>
        </div>

        {/* Form */}
        <div className="p-6">
          {isSubmitted ? (
            <div className="text-center py-8 animate-fade-in-up">
              <div className="w-16 h-16 rounded-full gradient-button mx-auto flex items-center justify-center mb-4">
                <Check className="w-8 h-8 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">
                Thank You!
              </h3>
              <p className="text-muted-foreground">
                We've received your application. Our team will reach out within 4 hours.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-foreground">Name</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Your full name"
                  value={formData.name}
                  onChange={(e) =>
                    setFormData({ ...formData, name: e.target.value })
                  }
                  required
                  className="mt-1.5 border-border focus:border-primary focus:ring-primary"
                />
              </div>

              <div>
                <Label htmlFor="email" className="text-foreground">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  required
                  className="mt-1.5 border-border focus:border-primary focus:ring-primary"
                />
              </div>

              <div>
                <Label htmlFor="phone" className="text-foreground">Phone Number</Label>
                <div className="flex gap-2 mt-1.5">
                  <Select
                    value={formData.countryCode}
                    onValueChange={(value) =>
                      setFormData({ ...formData, countryCode: value })
                    }
                  >
                    <SelectTrigger className="w-24 border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="+91">+91 🇮🇳</SelectItem>
                      <SelectItem value="+1">+1 🇺🇸</SelectItem>
                      <SelectItem value="+971">+971 🇦🇪</SelectItem>
                      <SelectItem value="+44">+44 🇬🇧</SelectItem>
                      <SelectItem value="+61">+61 🇦🇺</SelectItem>
                    </SelectContent>
                  </Select>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="Phone number"
                    value={formData.phone}
                    onChange={(e) =>
                      setFormData({ ...formData, phone: e.target.value })
                    }
                    required
                    className="flex-1 border-border focus:border-primary focus:ring-primary"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="businessType" className="text-foreground">Business Type</Label>
                <Select
                  value={formData.businessType}
                  onValueChange={(value) =>
                    setFormData({ ...formData, businessType: value })
                  }
                  required
                >
                  <SelectTrigger className="mt-1.5 border-border">
                    <SelectValue placeholder="Select your business type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="small">Small Business</SelectItem>
                    <SelectItem value="medium">Medium Business</SelectItem>
                    <SelectItem value="large">Large Enterprise</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full gradient-button text-primary-foreground border-0 py-6 text-lg font-semibold hover-glow transition-all"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  "Submit Application"
                )}
              </Button>

              <p className="text-center text-sm text-muted-foreground">
                Our team will get back to you within 4 hours. Fast response guaranteed.
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContactModal;
