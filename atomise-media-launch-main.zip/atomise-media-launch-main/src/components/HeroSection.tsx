import { ArrowRight, Globe, Zap, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import logo from "@/assets/logo.png";

interface HeroSectionProps {
  onOpenModal: () => void;
}

const HeroSection = ({ onOpenModal }: HeroSectionProps) => {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Gradient */}
      <div className="absolute inset-0 gradient-hero opacity-30" />
      
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-64 h-64 bg-primary/10 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-float" style={{ animationDelay: "-3s" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-secondary/30 rounded-full blur-3xl animate-pulse-slow" />
      </div>

      <div className="container relative z-10 mx-auto px-4 md:px-8 py-32">
        <div className="max-w-4xl mx-auto text-center">
          {/* Logo */}
          <div className="mb-4 animate-fade-in-up">
            <img src={logo} alt="Atomise Media" className="h-52 md:h-72 w-auto mx-auto" />
          </div>

          {/* Subheading */}
          <p className="text-xl md:text-2xl font-medium text-foreground mb-6 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            Your Brand, Distributed Everywhere with Precision
          </p>

          {/* Body Text */}
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
            We manage your complete digital presence across Instagram, Facebook, and YouTube—creating premium content that drives engagement, builds trust, and delivers results.
          </p>

          {/* Compelling Hook */}
          <div className="bg-card/60 backdrop-blur-sm rounded-2xl p-6 max-w-2xl mx-auto mb-10 border border-border shadow-soft animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            <p className="text-foreground italic leading-relaxed">
              "Imagine never worrying about social media again. Imagine waking up to a perfectly managed brand presence, growing engagement, and leads flowing in—all handled with the care and precision your success deserves."
            </p>
          </div>

          {/* CTA Button */}
          <div className="animate-fade-in-up" style={{ animationDelay: "0.5s" }}>
            <Button
              onClick={onOpenModal}
              size="lg"
              className="gradient-button text-primary-foreground border-0 px-10 py-7 text-lg font-semibold hover-glow transition-all group"
            >
              Talk to Us
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-wrap justify-center gap-8 mt-16 animate-fade-in-up" style={{ animationDelay: "0.6s" }}>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Globe className="w-6 h-6 text-primary" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-foreground">India, USA, Dubai</p>
                <p className="text-sm text-muted-foreground">Global Reach</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Zap className="w-6 h-6 text-primary" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-foreground">4-Hour Response</p>
                <p className="text-sm text-muted-foreground">Guaranteed</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                <Award className="w-6 h-6 text-primary" />
              </div>
              <div className="text-left">
                <p className="font-semibold text-foreground">Premium Quality</p>
                <p className="text-sm text-muted-foreground">Every Delivery</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-foreground/30 flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-foreground/30 rounded-full" />
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
