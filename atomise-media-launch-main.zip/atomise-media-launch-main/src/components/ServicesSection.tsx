import { useState } from "react";
import { Play, Image, Layers, Video, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useScrollReveal } from "@/hooks/useScrollReveal";

interface ServicesSectionProps {
  onOpenModal: (serviceTitle?: string) => void;
}

const services = [
  {
    id: "ugc",
    name: "UGC Videos",
    icon: Video,
    heading: "User-Generated Content Videos",
    description:
      "Authentic, lifestyle-driven videos that look like customer testimonials. UGC-style content that builds trust and drives conversions—crafted specifically for your brand.",
    placeholder: "UGC Video Sample",
  },
  {
    id: "avatar",
    name: "AI Avatar",
    icon: User,
    heading: "AI Avatar Videos",
    description:
      "Your digital twin. Your voice. Your message. Lifelike AI avatars using your face and voice to deliver scripted content, announcements, and thought leadership—scaled infinitely.",
    placeholder: "AI Avatar Video Sample",
  },
  {
    id: "posters",
    name: "Posters",
    icon: Image,
    heading: "Custom Social Media Posters",
    description:
      "Eye-catching, brand-aligned graphics designed to stop the scroll. Every poster is crafted to match your visual identity and communicate your message clearly.",
    placeholder: "Poster Sample",
  },
  {
    id: "carousels",
    name: "Carousels",
    icon: Layers,
    heading: "Engaging Carousel Posts",
    description:
      "Multi-slide storytelling that educates, informs, and converts. Scroll-stopping carousels that keep audiences engaged and deliver your message across multiple frames.",
    placeholder: "Carousel Sample",
  },
];

const ServicesSection = ({ onOpenModal }: ServicesSectionProps) => {
  const [activeTab, setActiveTab] = useState("ugc");
  const { ref, isVisible } = useScrollReveal();

  return (
    <section id="services" className="py-24 bg-background">
      <div className="container mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            <span className="text-gradient">Testimonials</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Premium content. Exceptional results. Crafted for your brand.
          </p>
        </div>

        {/* Services Tabs */}
        <div
          ref={ref}
          className={`${isVisible ? "animate-fade-in-up" : "opacity-0"}`}
        >
          <Tabs
            value={activeTab}
            onValueChange={setActiveTab}
            className="w-full"
          >
            <TabsList className="w-full flex flex-wrap justify-center gap-2 bg-transparent mb-12 h-auto">
              {services.map((service) => (
                <TabsTrigger
                  key={service.id}
                  value={service.id}
                  className="flex items-center gap-2 px-6 py-3 rounded-full data-[state=active]:gradient-button data-[state=active]:text-primary-foreground data-[state=inactive]:bg-secondary data-[state=inactive]:text-foreground transition-all"
                >
                  <service.icon className="w-4 h-4" />
                  {service.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {services.map((service) => (
              <TabsContent
                key={service.id}
                value={service.id}
                className="animate-fade-in"
              >
                <div className="bg-card rounded-2xl p-8 md:p-12 border border-border shadow-soft">
                  {/* Service Header */}
                  <div className="text-center mb-10">
                    <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                      <service.icon className="w-8 h-8 text-primary" />
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                      {service.heading}
                    </h3>
                    <p className="text-muted-foreground max-w-2xl mx-auto">
                      {service.description}
                    </p>
                  </div>

                  {/* Video/Image Placeholders */}
                  <div className="grid md:grid-cols-2 gap-6 mb-10">
                    {[1, 2].map((i) => (
                      <div
                        key={i}
                        className="aspect-video rounded-xl bg-secondary/50 border border-border flex items-center justify-center group hover:border-primary/50 transition-colors cursor-pointer"
                      >
                        <div className="text-center">
                          {service.id === "posters" || service.id === "carousels" ? (
                            <Image className="w-12 h-12 text-muted-foreground/50 mx-auto mb-3" />
                          ) : (
                            <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-3 group-hover:bg-primary/30 transition-colors">
                              <Play className="w-8 h-8 text-primary" />
                            </div>
                          )}
                          <p className="text-muted-foreground text-sm">
                            {service.placeholder} {i}
                          </p>
                          <p className="text-xs text-muted-foreground/70 mt-1">
                            (Sample coming soon)
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* CTA Button */}
                  <div className="text-center">
                    <Button
                      onClick={() => onOpenModal(`I'm interested in ${service.heading}`)}
                      size="lg"
                      className="gradient-button text-primary-foreground border-0 px-10 py-6 text-lg font-semibold hover-glow transition-all"
                    >
                      WANT This Service
                    </Button>
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
