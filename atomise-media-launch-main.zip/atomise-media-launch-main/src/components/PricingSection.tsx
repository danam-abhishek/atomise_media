import { Check, Star, Crown, Gem, ScrollText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useScrollReveal } from "@/hooks/useScrollReveal";

interface PricingSectionProps {
  onOpenModal: () => void;
}

const plans = [
  {
    name: "Starter",
    price: "₹25,000",
    period: "/month",
    subtitle: "Perfect for growing businesses ready to go consistent",
    icon: Star,
    cardClass: "gradient-card-starter",
    textClass: "text-foreground",
    priceClass: "text-deep-navy",
    features: [
      "Multi-Platform Management (Instagram, Facebook, YouTube)",
      "Post up to 30 videos/month we handle for you (1 per day)",
      "3 custom-designed posts per week (carousels or posters)",
      "Professional captions & hashtag optimization",
      "Brand-aligned content using your logo, website, and colors",
    ],
    delivery: "12 custom posts/month + up to 30 client videos posted",
    badge: null,
  },
  {
    name: "Growth",
    price: "₹40,000",
    period: "/month",
    subtitle: "Everything in Starter + Lead Generation",
    icon: Gem,
    cardClass: "gradient-card-growth",
    textClass: "text-foreground",
    priceClass: "text-deep-navy",
    features: [
      "Everything in Starter Plan",
      "Instagram Auto-Response System (DM to commenters)",
      "Lead Data Collection & Tracking",
      "Monthly organized lead database delivered to you",
      "Priority support",
    ],
    delivery: "Turn engagement into leads while managing your brand",
    badge: null,
  },
  {
    name: "Premium",
    price: "₹60,000",
    period: "/month",
    subtitle: "Everything in Growth + Professional Video Content",
    icon: Crown,
    cardClass: "gradient-card-premium",
    textClass: "text-primary-foreground",
    priceClass: "text-primary-foreground",
    features: [
      "Everything in Growth Plan",
      "3 AI-generated UGC videos per week (12/month)",
      "Lifestyle & testimonial-style video content",
      "Fully branded with your logo and identity",
      "Product/service highlights in UGC format",
      "Authentic customer-style content that converts",
    ],
    delivery: "12 UGC videos + 12 custom posts + lead generation + up to 30 client videos",
    badge: "MOST POPULAR",
  },
  {
    name: "Enterprise",
    price: "₹1,00,000",
    period: "/month",
    subtitle: "The Ultimate Social Media Powerhouse",
    icon: ScrollText,
    cardClass: "gradient-card-enterprise",
    textClass: "text-primary-foreground",
    priceClass: "text-primary-foreground",
    features: [
      "Everything in Growth Plan (Instagram DMs + Leads)",
      "3 AI Avatar videos per week (12/month)",
      "Your personalized digital twin delivering your message",
      "Custom-scripted brand announcements",
      "Face + voice cloning for authentic presence",
      "Perfect for founders, CEOs, coaches, and thought leaders",
      "White-glove service with priority turnaround",
    ],
    delivery: "12 AI avatar videos + 12 custom posts + lead generation + up to 30 client videos",
    badge: "PREMIUM",
  },
];

const PricingSection = ({ onOpenModal }: PricingSectionProps) => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section id="pricing" className="py-24 bg-secondary/30">
      <div className="container mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Choose Your <span className="text-gradient">Growth Plan</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Transparent pricing. Premium service. Exceptional results.
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div
          ref={ref}
          className={`grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12 ${
            isVisible ? "animate-fade-in-up" : "opacity-0"
          }`}
        >
          {plans.map((plan, index) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-6 ${plan.cardClass} hover-lift transition-all border border-border/20`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Badge */}
              {plan.badge && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="px-4 py-1 text-xs font-bold bg-primary text-primary-foreground rounded-full">
                    {plan.badge}
                  </span>
                </div>
              )}

              {/* Plan Icon */}
              <div className={`w-14 h-14 rounded-2xl ${plan.badge ? 'bg-primary-foreground/20' : 'bg-deep-navy/10'} flex items-center justify-center mb-5 shadow-md`}>
                <plan.icon className={`w-7 h-7 ${plan.badge ? 'text-primary-foreground' : 'text-deep-navy'}`} strokeWidth={1.5} />
              </div>

              {/* Plan Name */}
              <h3 className={`text-xl font-bold ${plan.textClass} mb-2`}>
                {plan.name}
              </h3>

              {/* Price */}
              <div className="mb-4">
                <span className={`text-3xl font-bold ${plan.priceClass}`}>
                  {plan.price}
                </span>
                <span className={`text-sm ${plan.badge ? 'text-primary-foreground/70' : 'text-muted-foreground'}`}>
                  {plan.period}
                </span>
              </div>

              {/* Subtitle */}
              <p className={`text-sm ${plan.badge ? 'text-primary-foreground/80' : 'text-muted-foreground'} mb-6`}>
                {plan.subtitle}
              </p>

              {/* Features */}
              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <Check className={`w-4 h-4 mt-1 flex-shrink-0 ${plan.badge ? 'text-primary-foreground' : 'text-primary'}`} />
                    <span className={`text-sm ${plan.textClass}`}>{feature}</span>
                  </li>
                ))}
              </ul>

              {/* Delivery Info */}
              <div className={`text-xs ${plan.badge ? 'text-primary-foreground/70' : 'text-muted-foreground'} mb-6 p-3 rounded-lg ${plan.badge ? 'bg-primary-foreground/10' : 'bg-background/50'}`}>
                <span className="font-semibold">Total Delivery:</span> {plan.delivery}
              </div>

              {/* CTA Button */}
              <Button
                onClick={onOpenModal}
                className={`w-full ${
                  plan.badge
                    ? 'bg-primary-foreground text-deep-navy hover:bg-primary-foreground/90'
                    : 'gradient-button text-primary-foreground hover-glow'
                } transition-all`}
              >
                Talk to Us
              </Button>
            </div>
          ))}
        </div>

        {/* Custom Plan */}
        <div className="gradient-hero rounded-2xl p-8 md:p-12 text-center">
          <h3 className="text-2xl md:text-3xl font-bold text-deep-navy mb-4">
            Need Something Different?
          </h3>
          <p className="text-deep-navy/80 max-w-2xl mx-auto mb-8">
            Every business is unique. If our plans don't perfectly fit your needs, let's build a custom package tailored exactly to your goals, budget, and vision.
          </p>

          <div className="flex flex-wrap justify-center gap-4 mb-8">
            {[
              "Flexible pricing",
              "Custom content mix",
              "Additional platforms (LinkedIn, Twitter, Pinterest)",
              "Higher posting frequency",
              "Dedicated creative team",
              "Whatever you need, we'll make it happen",
            ].map((feature, i) => (
              <div
                key={i}
                className="flex items-center gap-2 px-4 py-2 bg-background/50 rounded-full"
              >
                <Check className="w-4 h-4 text-primary" />
                <span className="text-sm text-deep-navy">{feature}</span>
              </div>
            ))}
          </div>

          <Button
            onClick={onOpenModal}
            size="lg"
            className="gradient-button text-primary-foreground border-0 px-10 py-6 text-lg font-semibold hover-glow transition-all"
          >
            Talk to Us
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
