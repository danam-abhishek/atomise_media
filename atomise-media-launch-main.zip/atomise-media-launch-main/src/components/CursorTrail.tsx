import { useState, useEffect, useCallback } from "react";
import { Instagram, Facebook, Youtube, Linkedin, Twitter } from "lucide-react";

interface TrailIcon {
  id: number;
  x: number;
  y: number;
  icon: typeof Instagram;
  rotation: number;
}

const icons = [Instagram, Facebook, Youtube, Linkedin, Twitter];

const CursorTrail = () => {
  const [trail, setTrail] = useState<TrailIcon[]>([]);
  const [lastSpawn, setLastSpawn] = useState(0);

  const handleMouseMove = useCallback((e: MouseEvent) => {
    const now = Date.now();
    // Spawn icon every 80ms for smooth trail
    if (now - lastSpawn < 80) return;
    
    setLastSpawn(now);
    
    const newIcon: TrailIcon = {
      id: now,
      x: e.clientX,
      y: e.clientY,
      icon: icons[Math.floor(Math.random() * icons.length)],
      rotation: Math.random() * 360,
    };

    setTrail((prev) => [...prev.slice(-15), newIcon]); // Keep max 15 icons
  }, [lastSpawn]);

  useEffect(() => {
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, [handleMouseMove]);

  // Remove icons after animation
  useEffect(() => {
    const cleanup = setInterval(() => {
      const now = Date.now();
      setTrail((prev) => prev.filter((icon) => now - icon.id < 1000));
    }, 100);
    return () => clearInterval(cleanup);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-[9999] overflow-hidden">
      {trail.map((item) => {
        const IconComponent = item.icon;
        const age = Date.now() - item.id;
        const opacity = Math.max(0, 1 - age / 1000);
        const scale = 0.5 + (1 - age / 1000) * 0.5;
        
        return (
          <div
            key={item.id}
            className="absolute"
            style={{
              left: item.x,
              top: item.y,
              transform: `translate(-50%, -50%) rotate(${item.rotation}deg) scale(${scale})`,
              opacity,
              transition: "opacity 0.1s ease-out",
            }}
          >
            <IconComponent 
              className="w-5 h-5 text-primary drop-shadow-lg" 
              strokeWidth={2}
            />
          </div>
        );
      })}
    </div>
  );
};

export default CursorTrail;
