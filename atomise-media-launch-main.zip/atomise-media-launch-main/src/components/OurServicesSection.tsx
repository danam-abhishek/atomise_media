import { Palette, Video, Calendar, TrendingUp, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useScrollReveal } from "@/hooks/useScrollReveal";

interface OurServicesSectionProps {
  onOpenModal: () => void;
}

const services = [
  {
    id: "content-creation",
    icon: Palette,
    title: "Content Creation & Design",
    description: "Eye-catching visuals that stop the scroll. Our design team crafts every post to match your brand identity and drive engagement.",
    features: [
      "Custom carousels for storytelling",
      "Branded posters and graphics",
      "Promotional materials and announcements",
      "Platform-optimized content formats",
      "Visual assets aligned with your brand guidelines",
    ],
    tagline: "Every post designed to convert.",
  },
  {
    id: "video-production",
    icon: Video,
    title: "Video Production",
    description: "Professional video content without the production hassle. From UGC-style testimonials to AI-powered avatar videos, we create video content that captivates.",
    features: [
      "AI-Generated UGC videos (authentic lifestyle content)",
      "AI Avatar videos (your digital twin, your voice)",
      "Scripted brand messages and announcements",
      "Professional editing with your logo and branding",
      "Product/service highlight videos",
    ],
    tagline: "Video content that feels real, converts fast.",
  },
  {
    id: "social-media",
    icon: Calendar,
    title: "Social Media Management",
    description: "Put your social media on autopilot—managed by real people. We handle daily posting, optimize captions, and ensure your brand stays consistent across all platforms.",
    features: [
      "Daily posting across Instagram, Facebook, YouTube",
      "AI-powered caption writing and hashtags",
      "Multi-platform content distribution",
      "Brand voice consistency",
      "Content scheduling and calendar management",
      "Up to 30 client videos posted monthly",
    ],
    tagline: "Your brand, always active. Managed by humans, not bots.",
  },
  {
    id: "growth-engagement",
    icon: TrendingUp,
    title: "Growth & Engagement",
    description: "Turn followers into leads. Our growth strategies drive engagement, capture data, and deliver qualified prospects directly to you.",
    features: [
      "Instagram auto-response to comments",
      "Lead capture from engaged audiences",
      "Monthly organized lead database",
      "Performance tracking and insights",
      "Monthly reports on reach, engagement, and growth",
      "Data-driven optimization",
    ],
    tagline: "Engagement that converts into revenue.",
  },
];

const ServiceCard = ({ service, index }: { service: typeof services[0]; index: number }) => {
  const { ref, isVisible } = useScrollReveal(0.1);
  
  return (
    <div
      ref={ref}
      className={`bg-card rounded-xl p-8 md:p-10 border border-border shadow-soft transition-all duration-300 hover:shadow-lg hover:-translate-y-2 hover:border-primary/30 group ${
        isVisible ? "animate-fade-in-up" : "opacity-0"
      }`}
      style={{ animationDelay: `${index * 100}ms` }}
    >
      {/* Icon */}
      <div className="w-16 h-16 rounded-2xl gradient-button flex items-center justify-center mb-6 mx-auto group-hover:shadow-glow transition-shadow">
        <service.icon className="w-8 h-8 text-primary-foreground" />
      </div>

      {/* Title */}
      <h3 className="text-xl md:text-2xl font-bold text-deep-navy text-center mb-4">
        {service.title}
      </h3>

      {/* Description */}
      <p className="text-muted-foreground text-center mb-6 leading-relaxed">
        {service.description}
      </p>

      {/* Features */}
      <div className="space-y-3 mb-6">
        <p className="text-sm font-semibold text-foreground">What We {service.id === "video-production" ? "Produce" : service.id === "social-media" ? "Manage" : service.id === "growth-engagement" ? "Deliver" : "Create"}:</p>
        <ul className="space-y-2">
          {service.features.map((feature, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
              <Check className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Tagline */}
      <p className="text-sm italic text-sky-blue text-center font-medium">
        {service.tagline}
      </p>
    </div>
  );
};

const OurServicesSection = ({ onOpenModal }: OurServicesSectionProps) => {
  const { ref: headerRef, isVisible: headerVisible } = useScrollReveal();

  return (
    <section id="services" className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-4 md:px-8">
        {/* Section Header */}
        <div
          ref={headerRef}
          className={`text-center max-w-3xl mx-auto mb-16 ${
            headerVisible ? "animate-fade-in-up" : "opacity-0"
          }`}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            <span className="text-gradient">Our Services</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Everything you need to dominate social media—all in one place.
          </p>
        </div>

        {/* Service Cards Grid */}
        <div className="grid md:grid-cols-2 gap-8 md:gap-10 max-w-6xl mx-auto mb-16">
          {services.map((service, index) => (
            <ServiceCard key={service.id} service={service} index={index} />
          ))}
        </div>

        {/* CTA */}
        <div className="text-center">
          <p className="text-lg text-muted-foreground mb-6">
            Want to see how we can transform your brand?
          </p>
          <Button
            onClick={onOpenModal}
            size="lg"
            className="gradient-button text-primary-foreground border-0 px-10 py-6 text-lg font-semibold hover-glow transition-all"
          >
            Talk to Us
          </Button>
        </div>
      </div>
    </section>
  );
};

export default OurServicesSection;
